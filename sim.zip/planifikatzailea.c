#include "globals.h"

void planifikatzailea(int cpu, int core, int hharia){


}
