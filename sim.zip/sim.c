/**
 * Planifikatzailea v1 SE/SO
 */

#include "si.h"
#include "procs.h"
#include "sched.h"
#include "computation_engine.h"
#include "sistema.h"
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char **argv){
	
	char * fitx_izena;
        int cpu_k, core_k, hhariak_k, gpu_k;

	if (argc != 8){
		printf("Erabilera: planifikatzailea politika politika fitxategia cpu core hhariak gpu\n");
		exit(-1);
	}

	fitx_izena = argv[3];
	cpu_k = atoi(argv[4]);
	core_k = atoi(argv[5]);
	hhariak_k = atoi(argv[6]);
	gpu_k = atoi(argv[7]);

	sortu_allprocs_ilara();
	sortu_prest_ilara();
	sortu_computation_engine(cpu_k, core_k, hhariak_k, gpu_k);

	irakurri_fitxategia(fitx_izena);

        hasi_sistema();

}
