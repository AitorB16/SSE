#ifndef _list
#define _list

typedef struct node_list {
  void *data;
  struct node_list *next;
  struct node_list *prev;
} node_list;
 
typedef struct list_t {
  long length;
  int t_size;
  struct node_list *head;
  struct node_list *tail;
} list_t;
 
void list_initialize(list_t *list, int t_size);

void list_destroy(list_t *list);
 
node_list *list_insert(list_t *list, void *elem);

void list_append(list_t *list, void *elem);

long list_length(list_t *list);

long list_empty(list_t *l);

void list_head(list_t *list, void **elem);

void list_head_node(list_t *list, void **elem);

void list_tail(list_t *list, void **elem);

void list_tail_node(list_t *l, void **elem);


#endif
