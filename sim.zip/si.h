#ifndef _si
#define _si

void irakurri_fitxategia(char *fitx_izena);

#endif
