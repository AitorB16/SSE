#ifndef _planifikatzailea
#define _planifikatzaile

void planifikatzailea(int cpu, int core, int hharia);

#endif

