#ifndef _sistema
#define _sistema

void hasi_sistema();

#endif
