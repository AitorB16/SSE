#ifndef _misc
#define _misc

typedef enum planifikazio_politika_t{
    FIFO,
    RR,
    LEHENTASUNA,
    LITERAL_END 
} planifikazio_politika_t;

typedef enum kanporaketa_politika_t{
    EZ_KANPORATZAILEA,
    KANPORATZAILEA,
    LITERAL_END 
} kanporaketa_politika_t;

#endif
