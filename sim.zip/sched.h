#ifndef _sched
#define _sched

void sortu_prest_ilara();

void sartu_prozesua_prest_ilaran(struct pcb* proz);

#endif
